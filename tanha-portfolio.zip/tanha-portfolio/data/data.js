/* Portfolio content. The admin panel exports an updated copy of this file. */
window.PORTFOLIO={
 "v": 5,
 "p": {
  "name": "Tanha Tabassum",
  "tag": "Student · Aspiring Software Engineer",
  "uni": "Your University Name",
  "dept": "Your Department",
  "intro": "Write a short introduction about yourself here.",
  "photo": "assets/images/profile.jpg",
  "bgfx": {
   "blur": 3
  }
 },
 "s": {
  "education": [
   {
    "t": "University — expected graduation 2029",
    "d": "Add your degree, institution, results and achievements."
   }
  ],
  "volunteering": [
   {
    "t": "Scout",
    "d": "Add your role, dates and what you did."
   },
   {
    "t": "Red Crescent",
    "d": "Add your role, dates and what you did."
   }
  ],
  "hobbies": [
   {
    "t": "My interests",
    "d": "Add your hobbies here."
   }
  ],
  "extra": [
   {
    "t": "Extracurricular activity",
    "d": "Add clubs, events, awards and achievements."
   }
  ],
  "projects": [
   {
    "t": "Garage Management System",
    "d": "Describe what it does, the technologies used and your role. Add a screenshot and a link.",
    "l": "",
    "img": ""
   }
  ],
  "connect": [
   {
    "t": "Email",
    "d": "yourname@example.com",
    "l": "mailto:yourname@example.com"
   }
  ],
  "others": [
   {
    "t": "Additional information",
    "d": "Anything else you want visitors to know."
   }
  ]
 }
};
