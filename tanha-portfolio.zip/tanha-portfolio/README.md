# Tanha Tabassum — Personal Portfolio

A static portfolio website (HTML + CSS + JavaScript). No build step, no server.

## Structure
```
index.html        Public site — visitors only view (no admin code is loaded)
admin.html        Admin page — password login + editor (not linked from the public site)
css/style.css     All styles
js/utils.js       Helpers, shared state
js/render.js      Public views: landing, about, dashboard, appearance settings
js/admin.js       Admin only: login, add/edit/delete, profile, background, export
js/main.js        Starts the app
data/data.js      ALL portfolio content (name, sections, projects, password hash)
assets/           Images and favicon
```

## Publish on GitHub Pages
1. Create a repository and upload everything in this folder (keep the folders).
2. Repository **Settings → Pages** → choose the main branch / root → Save.
3. Share the link GitHub gives you (e.g. `https://USERNAME.github.io/REPO/`).

## Edit your portfolio (admin)
1. Open `YOUR-LINK/admin.html`. The first time, create an admin password.
2. Edit profile, sections, projects, background picture. Changes are kept as a draft in your browser.
3. Press **Download data.js**, then upload it to GitHub in the `data/` folder (replace the old file).
4. **Important:** do this once right after creating the password, so your password hash is in `data.js`.
5. Visitors see the new content after GitHub updates (about a minute).

## Visitors vs admin
- Visitors use `index.html`: view only. No edit buttons, no login link, no admin code.
- Only `admin.html` can edit, and only after the password.
- Visitors can still change their own font, theme and dark mode (saved on their device only).

## Security note
GitHub Pages is static hosting, so the password check runs in the browser (password stored as a PBKDF2 hash in `data.js`). This keeps visitors out of the editor and
cannot change the live site by itself — only uploading to your GitHub account can. Use a long, unique password. It is not bank-level security.

## Tips
- Keep images small. Uploaded images are resized, but you can also put files in `assets/images/` and use the path (e.g. `assets/images/profile.jpg`) in `data.js`.
- To test locally, just open `index.html` in a browser.
